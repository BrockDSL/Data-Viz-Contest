The census variables were downloaded from the Canadian Census Analyser database and joined with the census boundary files which were downloaded from Scholars GeoPortal.

http://datacentre.chass.utoronto.ca/census/

https://geo2.scholarsportal.info/

For more information about the data or process, contact Sharon Janzen sjanzen@brocku.ca